import logo from './logo.svg';
import './App.css';
import DoctorShow from './components/ShowDoctors/showDoctors';

import DoctorSearchById from './components/SearchDoctorId/searchDoctorId';
import SearchPatientByHealthProblem from './components/SearchbyHealthProblem/searchbyhealthProblem';
import SearchPatientByID from './components/SearchPatientById/searchPatientbyId';
import SearchPatientByDoctorID from './components/SearchPatientbyDoctorId/searchPatientbyDoctorId';
import AddDoctor from './components/AddDoctor/AddDoctor';
import AddPatient from './components/AddPatient/addPatient';
import PatientShow from './components/ShowPatients/showPatients';
import SearchDoctorBySpecialization from './components/SearchSpeciality/searchSpeciality';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Menu from './components/Menu/menu';
import Login from './components/Login/login';
import SearchByMobileNo from './components/SearchByMobileNo/searchbyMobileNo';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
     <Routes>
     <Route path="/" element={<Login/>}/>
     <Route path="/menu" element={<Menu/>}/>
      <Route path="/DoctorShow" element={<DoctorShow/>}/>
      <Route path="/SearchSpeciality" element={<SearchDoctorBySpecialization/>}/>
      <Route path="/DoctorSearchById" element={<DoctorSearchById/>}/>
      <Route path="/SearchPatientByHealthProblem" element={<SearchPatientByHealthProblem/>}/>
      <Route path="/SearchPatientByID" element={<SearchPatientByID/>}/>
      <Route path="/PatientByDoctorID" element={<SearchPatientByDoctorID/>}/>
      <Route path="/AddDoctor" element={<AddDoctor/>}/>
      <Route path="/AddPatient" element={<AddPatient/>}/>
      <Route path="/PatientShow" element={<PatientShow/>}/>
      <Route path="/SearchByMobileNo" element={<SearchByMobileNo/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
