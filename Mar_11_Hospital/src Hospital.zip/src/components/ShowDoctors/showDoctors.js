import axios from "axios";
import { useEffect, useState } from "react";
import { BaseURL } from "../../utils";


const DoctorShow = () => {
    
    const[doctor,setDoctorData] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            const response = await axios.get(`${BaseURL}/api/Doctors`);
            setDoctorData(response.data)
            console.log(response.data);
        };
        fetchData()
    },[])


    return(
        <div>
         
           
             <table border="3" align="center">
          <tr>
          <th>DoctorID</th>
            <th>DoctorName</th>
            <th>Speciality</th>
            <th>Qualification</th>
            <th>Doctor Username</th>
            <th>Email</th>
            <th>Mobile</th>
          </tr>
          {doctor.map((item) => 
            <tr>
              <td>{item.doctorId}</td>
              <td>{item.doctorName}</td>
              <td>{item.speciality}</td>
              <td>{item.qualification}</td>
              <td>{item.doctorUserName}</td>
              <td>{item.email}</td>
              <td>{item.mobile}</td>
            </tr>
          )}
        </table>
        </div>
    )
      }
       export default DoctorShow;