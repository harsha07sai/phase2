import React, { useState } from "react";
import axios from "axios";
import { BaseURL } from "../../utils";


const SearchPatientByID = () => {
  const [patientId, setPatientId] = useState("");
  const [patient, setPatient] = useState(null);
  const [error, setError] = useState("");

  const fetchPatient = async () => {
    try {
      setError("");
      const response = await axios.get(`${BaseURL}/api/Patients/${patientId}`);
      setPatient(response.data);
    } catch (err) {
      setPatient(null);
      setError(`No patient found with ID: ${patientId}`);
    }
  };

  return (
    <div className="container">
     
      <h2>Search Patient by ID</h2>
      <input
        type="number"
        value={patientId}
        onChange={(e) => setPatientId(e.target.value)}
        placeholder="Enter Patient ID"
      />
      <button onClick={fetchPatient}>Search</button>

      {error && <p className="error">{error}</p>}

      {patient && (
        <div className="patient-details">
          <h3>Patient Details</h3>
          <p><strong>ID:</strong> {patient.patientId}</p>
          <p><strong>Name:</strong> {patient.patientName}</p>
          <p><strong>Health Problem:</strong> {patient.healthProblem}</p>
          <p><strong>Doctor ID:</strong> {patient.doctorId}</p>
          <p><strong>Email:</strong> {patient.email}</p>
          <p><strong>Mobile No:</strong> {patient.mobileNo}</p>
          <p><strong>Age:</strong> {patient.age}</p>
        </div>
      )}
    </div>
  );
};

export default SearchPatientByID;