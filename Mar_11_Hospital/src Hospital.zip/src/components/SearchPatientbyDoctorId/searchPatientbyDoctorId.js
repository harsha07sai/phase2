import React, { useState } from "react";
import axios from "axios";
import { BaseURL } from "../../utils";


const SearchPatientByDoctorID = () => {
  const [doctorId, setDoctorId] = useState("");
  const [patients, setPatients] = useState([]);
  const [error, setError] = useState("");

  const fetchPatients = async () => {
    try {
      setError("");
      const response = await axios.get(`${BaseURL}/api/Patients/byDoctorId/${doctorId}`);
      setPatients(response.data);
    } catch (err) {
      setPatients([]);
      setError(`No patients found for doctor with ID: ${doctorId}`);
    }
  };

  return (
    <div className="container">
  
      <h2>Search Patients by Doctor ID</h2>
      <input
        type="number"
        value={doctorId}
        onChange={(e) => setDoctorId(e.target.value)}
        placeholder="Enter Doctor ID"
      />
      <button onClick={fetchPatients}>Search</button>

      {error && <p className="error">{error}</p>}

      {patients.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Health Problem</th>
              <th>Doctor ID</th>
              <th>Email</th>
              <th>Mobile No</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((patient) => (
              <tr key={patient.patientId}>
                <td>{patient.patientId}</td>
                <td>{patient.patientName}</td>
                <td>{patient.healthProblem}</td>
                <td>{patient.doctorId}</td>
                <td>{patient.email}</td>
                <td>{patient.mobileNo}</td>
                <td>{patient.age}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default SearchPatientByDoctorID;