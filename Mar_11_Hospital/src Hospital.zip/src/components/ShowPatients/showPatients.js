import axios from "axios";
import { useEffect, useState } from "react";
import { BaseURL } from "../../utils";


const PatientShow = () => {
    
    const[patient,setPatientData] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            const response = await axios.get(`${BaseURL}/api/patients`);
            setPatientData(response.data)
            console.log(response.data);
        };
        fetchData()
    },[])


    return(
        <div>
         
           
             <table border="3" align="center">
          <tr>
          <th>PatientId</th>
            <th>healthProblem</th>
            <th>DoctorId</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>age</th>
          </tr>
          {patient.map((item) => 
            <tr>
              <td>{item.patientId}</td>
              <td>{item.healthProblem}</td>
              <td>{item.doctorId}</td>
              <td>{item.email}</td>
              <td>{item.mobileNo}</td> 
              <td>{item.age}</td>
              
            </tr>
          )}
        </table>
        </div>
    )
      }
       export default PatientShow;