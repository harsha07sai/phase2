import React, { useState } from 'react';
import axios from 'axios';

const DoctorSearchById = () => {
  const [doctorId, setDoctorId] = useState('');
  const [doctor, setDoctor] = useState(null);
  const [error, setError] = useState(null);

  const handleSearchById = async () => {
    try {
      const response = await axios.get(`http://localhost:5076/api/Doctors/${doctorId}`);
      setDoctor(response.data);
      setError(null);  // Clear any previous errors
    } catch (error) {
      setError(error.response ? error.response.data : 'An error occurred');
      setDoctor(null);  // Clear any previous doctor data
    }
  };

  return (
    <div>
      <h2>Search Doctor by ID</h2>
      <div>
        <input
          type="number"
          placeholder="Enter Doctor ID"
          value={doctorId}
          onChange={(e) => setDoctorId(e.target.value)}
        />
        <button onClick={handleSearchById}>Search</button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {doctor && (
        <table border="1" cellPadding="10" cellSpacing="0">
          <thead>
            <tr>
              <th>Field</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Doctor ID</td>
              <td><b>{doctor.doctorId}</b></td>
            </tr>
            <tr>
              <td>Doctor Name</td>
              <td><b>{doctor.doctorName}</b></td>
            </tr>
            <tr>
              <td>Speciality</td>
              <td><b>{doctor.speciality}</b></td>
            </tr>
            <tr>
              <td>Qualification</td>
              <td><b>{doctor.qualification}</b></td>
            </tr>
            <tr>
              <td>Doctor Username</td>
              <td><b>{doctor.doctorUserName}</b></td>
            </tr>
            <tr>
              <td>Email</td>
              <td><b>{doctor.email}</b></td>
            </tr>
            <tr>
              <td>Mobile</td>
              <td><b>{doctor.mobile}</b></td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
};

export default DoctorSearchById;
