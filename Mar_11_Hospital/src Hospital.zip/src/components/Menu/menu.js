import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

const Menu = () => {
  return (
    <div className="container my-4">
      <h2 className="text-center mb-4">Welcome to the Hospital Management System</h2>

      <nav className="navbar navbar-expand-lg navbar-light bg-light p-3 rounded">
        <div className="container-fluid d-flex flex-wrap">
          <Link to="/DoctorSearchById" className="nav-link mx-3">🔍 Doctor By ID</Link>
          <Link to="/SearchSpeciality" className="nav-link mx-3">🔍 Doctor By Specialization</Link>
          <Link to="/SearchPatientByHealthProblem" className="nav-link mx-3">🔍 Patient By Health Problem</Link>
          <Link to="/PatientByDoctorID" className="nav-link mx-3">🔍 Patient By Doctor ID</Link>
          <Link to="/SearchPatientByID" className="nav-link mx-3">🔍 Patient By ID</Link>
          <Link to="/AddDoctor" className="nav-link mx-3">➕ Add Doctor</Link>
          <Link to="/AddPatient" className="nav-link mx-3">➕ Add Patient</Link>
          <Link to="/DoctorShow" className="nav-link mx-3">👨‍⚕️ Show Doctors</Link>
          <Link to="/SearchByMobileNo" className="nav-link mx-3">📞 Doctor By Mobile</Link>
        </div>
      </nav>
    </div>
  );
};

export default Menu;
