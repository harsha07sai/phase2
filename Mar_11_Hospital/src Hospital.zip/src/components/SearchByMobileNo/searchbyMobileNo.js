import React, { useState } from "react";
import axios from "axios";
import { BaseURL } from "../../utils";


const SearchByMobileNo = () => {
  const [mobileNo, setmobileNo] = useState("");
  const [doctors, setDoctors] = useState([]);
  const [error, setError] = useState("");

  const fetchDoctors = async () => {
    try {
      setError("");
      const response = await axios.get(`${BaseURL}/api/Doctors/byMobileNo/${mobileNo}`);
      setDoctors(response.data);
    } catch (err) {
      setDoctors([]);
      setError(`No Doctors found with mobile Number: ${mobileNo}`);
    }
  };

  return (
    <div className="container">
        
      <h2>Search Doctors by Mobile No</h2>
      <input
        type="text"
        value={mobileNo}
        onChange={(e) => setmobileNo(e.target.value)}
        placeholder="Enter Mobile No"
      />
      <button onClick={fetchDoctors}>Search</button>

      {error && <p className="error">{error}</p>}

      {doctors.length > 0 && (
        <table>
          <thead>
            <tr>
              <th>DoctorID</th>
              <th>DoctorName</th>
              <th>Speciality</th>
              <th>Qualification</th>
              <th>DoctorUserName</th>
              <th>email</th>
              <th>Mobile</th>
            </tr>
          </thead>
          <tbody>
            {doctors.map((doctors) => (
              <tr>
                <td>{doctors.doctorId}</td>
                <td>{doctors.doctorName}</td>
                <td>{doctors.speciality}</td>
                <td>{doctors.doctorUserName}</td>
                <td>{doctors.email}</td>
                <td>{doctors.mobile}</td>
                
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default SearchByMobileNo;